const User = require('./User');
const Gauge = require('./Gauge');
const Category = require('./Category');
const Admin = require('./Admin');
const Tracking = require('./Tracking');

module.exports = { User, Gauge, Category, Admin, Tracking };
